package com.xycode.xylibrary.exception;

/**
 * Created by Administrator on 2016/9/1.
 */
public class UnSupportFieldException extends RuntimeException{
    public UnSupportFieldException(String message) {
        super(message);
    }
}
