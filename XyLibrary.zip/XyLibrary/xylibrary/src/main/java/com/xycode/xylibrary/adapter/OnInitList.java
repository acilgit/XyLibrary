package com.xycode.xylibrary.adapter;

import java.util.List;

/**
 * Created by XY on 2017-06-13.
 */

public interface OnInitList {
    List getList() throws Exception;
}
