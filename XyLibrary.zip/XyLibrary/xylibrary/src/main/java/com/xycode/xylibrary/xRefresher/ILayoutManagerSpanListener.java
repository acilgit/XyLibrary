package com.xycode.xylibrary.xRefresher;

/**
 * 最后一页
 */
public interface ILayoutManagerSpanListener {
    int setSpanCount(int pos);
}
