package com.xycode.xylibrary.xRefresher;

/**
 * 最后一页
 */
public interface OnLastPageListener {
    void receivedList(boolean isLastPage);
}
