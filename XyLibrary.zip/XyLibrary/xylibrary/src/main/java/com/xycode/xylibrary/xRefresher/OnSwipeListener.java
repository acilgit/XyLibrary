package com.xycode.xylibrary.xRefresher;

/**
 * 刷新监听
 */
public interface OnSwipeListener {
    /**
     * Refresh
     */
    void onRefresh();
}
