package com.xycode.xylibrary.exception;

/**
 * Created by Administrator on 2016/9/1.
 */
public class XYException extends Exception{
    public XYException(String message) {
        super(message);
    }
}
