# XyLibrary
Android BaseLibrary 基础框架包,建立与快速开发，经历过二十余个商业项目的迭代开发，封装OkHttp请求，fresco图片加载，XAdapter, RecyclerView的封装 各类常用工具包，组件等

### 用法
Android Studio
  
    compile 'com.xycode.xylibrary:xylibrary:0.8.54'
    
    
初始化XyLibrary 

  Xy.init(context,isRelease);
  
  #### 详情下载查看请使用 Rxjava 最新分支 
